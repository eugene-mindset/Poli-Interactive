
# README

Anderson Adon (aadon1) and Eugene Asare (easare3)

## Deliverables

All deliverables asked of us are included in this zip.

## Issues

Our data had to be pulled from APIs which return results that weren't table-like.
To make it table like, the data from the XML files and different APIs had to be merged
together into CSVs. We had lots of trouble getting this to all play nicely and encode the data
so MySql would take it.

## Concerns

None.
